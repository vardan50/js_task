class Stack {
  constructor() {
    // haytararel datark zangavc stack i elementner@ pahelu hamar
    this.items = [];
  }

  //avelacnel elementner
  push(element) {
    this.items.push(element);
  }

  // heracnum ev veradardznum e verjin element@
  pop() {
    // stugum enq vor stack@ datark chlini
    if (this.isEmpty()) {
      return "Stack is empty";
    }
    // heracnum ev veradardznum e element@
    return this.items.pop();
  }

  // veradardznum e verjin element@ arandz stack ic heracnelu
  peek() {
    // stugum enq vor stack@ datark chlini
    if (this.isEmpty()) {
        
      return "Stack is empty";
    }
    // veradardznum e element@
    return this.items[this.items.length - 1];
  }

  // stugum enq vor stack@ datark chlini
  isEmpty() {
    // stack@ datark e ete erkarutyun@ 0 e
    return this.items.length === 0;
  }

  // veradardznum e stack i erkarutyun@
  size() {
    // stack i elementneri qanak@
    return this.items.length;
  }

  // tel stack i elementner@
  print() {

    console.log(this.items.toString());
  }
}

