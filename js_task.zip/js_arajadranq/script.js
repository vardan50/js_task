function fetchData() {
    fetch('https://jsonplaceholder.typicode.com/posts')
        .then(response => response.json())
        .then(data => {
            const dataDiv = document.getElementById('data');
            dataDiv.innerHTML = '<h2>Fetched Data:</h2>';
            data.forEach(item => {
                dataDiv.innerHTML += `<p>${item.title}</p>`;
            });
        })
        .catch(error => console.error('Error fetching data:', error));
}
