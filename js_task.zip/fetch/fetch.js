document.addEventListener('DOMContentLoaded', function () {
    const data = JSON.parse(sessionStorage.getItem('fetchedData'));
    const dataType = sessionStorage.getItem('dataType');
    const infoContainer = document.getElementById('info-container');

    if (data) {
        let content = '';

        switch (dataType) {
            case 'users':
                content = `
                    <h2>${data.name}</h2>
                    <p>Username: ${data.username}</p>
                    <p>Email: ${data.email}</p>
                    <p>Phone: ${data.phone}</p>
                    <p>Website: ${data.website}</p>
                `;
                break;
            case 'comments':
                content = `
                    <h2>Comment by ${data.name}</h2>
                    <p>Email: ${data.email}</p>
                    <p>${data.body}</p>
                `;
                break;
            case 'posts':
                content = `
                    <h2>${data.title}</h2>
                    <p>${data.body}</p>
                `;
                break;
            default:
                content = '<p>No data available</p>';
        }

        // Create a new card element
        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = content;

        // Append the card to the info container
        infoContainer.appendChild(card);
    } else {
        infoContainer.innerHTML = '<p>No data available</p>';
    }
});
