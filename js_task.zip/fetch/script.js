function fetchData(dataType) {
    let apiUrl = '';

    switch (dataType) {
        case 'users':
            apiUrl = 'https://jsonplaceholder.typicode.com/users/1';
            break;
        case 'comments':
            apiUrl = 'https://jsonplaceholder.typicode.com/comments/1';
            break;
        case 'posts':
            apiUrl = 'https://jsonplaceholder.typicode.com/posts/1';
            break;
        default:
            console.error('Invalid data type');
            return;
    }

    console.log(apiUrl);

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            console.log(data);
            sessionStorage.setItem('fetchedData', JSON.stringify(data));
            sessionStorage.setItem('dataType', dataType);
            window.location.href = 'info.html';
        })
        .catch(error => console.error('Error fetching data:', error));
}
